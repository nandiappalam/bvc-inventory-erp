# MODULE_WORKFLOWS

This folder contains workflow documentation per module.

Files (to be generated):
- `Purchase.md`
- `Sales.md`
- `PurchaseReturn.md`
- `SalesReturn.md`
- `Grind_FlourOut.md`
- `FlourOutReturn.md`
- `PapadIn.md`
- `Packing.md`
- `Advance.md`
- `Open.md`
- `WeightConversion.md`
- `Vouchers.md`
- `VehicleMovement.md`
- `Masters_CRUD.md`
- `Stock_Adjust.md`
- `Reports.md`

If a module is not applicable as a separate backend router, it will be documented under the closest matching router (e.g., `masters.js` for all config-driven masters).

