# PAGES_WORKFLOWS

This folder will contain one workflow markdown file per frontend route listed in `frontend/src/App.jsx`.

Naming convention:
- `route-<path>.md` (slashes replaced by `_`)
- Examples:
  - `route-_login.md`
  - `route-_entry_purchase-create.md`

Files will describe:
- UI steps
- initial data loading
- payload mapping to backend request
- save/update/delete workflows

