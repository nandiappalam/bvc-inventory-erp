# SYSTEM_WORKFLOWS.md

End-to-end workflow documentation for the whole application.

> This document is generated from the current project code (frontend routes in `frontend/src/App.jsx` and backend routes in `backend/routes/*`).

## 1) System lifecycle (global)

### 1.1 Boot
1. Backend starts: `backend/server.js`
   - Configures CORS, JSON parsing, static frontend hosting.
   - Registers API routers under `/api/*`.
   - Initializes master tables via `initializeMasterTables()` and runs `backend/autoMigrate`.
2. Frontend starts: `frontend/src/main.jsx`
   - Renders `frontend/src/App.jsx`.

### 1.2 Company selection + Auth
1. Public route: `/` and `/company-select`
   - Component: `frontend/src/components/CompanySelection.jsx`
   - Workflow:
     - Calls backend: `GET /api/companies` (through `frontend/src/services/api.js`)
     - Lists companies and allows select/update/delete/print.
     - When a company is selected:
       - Stores selected company in AuthContext (`selectedCompany`) and `localStorage`.
       - Navigates to `/auth-choice`.
2. Route: `/auth-choice`
   - Component: `frontend/src/components/AuthChoice.jsx`
3. Route: `/login`
   - Component: `frontend/src/components/LoginPage.jsx`
   - Workflow (from AuthContext contract):
     - Calls login endpoint (Tauri `invoke` in production Tauri mode; fetch in dev).
     - On success, AuthContext sets:
       - `user`, `company`, `selectedCompany`, `permissions`, `isAdmin`, `loginHistoryId`.
4. Protected area
   - In `frontend/src/App.jsx`, any `path="*"` loads `AppLayout`, which checks:
     - `user` exists, else redirects to `/login`.
     - `selectedCompany` exists.
   - `Navigation` renders sidebar/menu according to AuthContext permission checks.

### 1.3 Page workflow pattern (common)
Every page follows the same general lifecycle:
1. Page mounts.
2. Page loads required masters/list data using `frontend/src/services/api.js` / `frontend/src/utils/api*.js` wrappers.
3. User fills a form.
4. On Save/Submit:
   - Frontend sends a request to a matching backend endpoint under `/api/<module>`.
   - Backend validates inputs.
   - Backend writes to transaction tables.
   - Backend updates side-effect tables:
     - `stock` and `stock_lots` for inventory.
     - ledger tables through helper functions (where present).
5. Frontend navigates back to list or shows the updated display.

## 2) Module categories and their workflows

> Page-by-page details are in `MODULE_WORKFLOWS/*` and `PAGES_WORKFLOWS/*`.

### 2.1 Master modules (config-driven CRUD)
- Implemented by dynamic pages:
  - `DynamicMasterForm`, `DynamicMasterDisplay`
- Backend:
  - `backend/routes/masters.js`
- Common endpoints:
  - `GET /api/masters/:type` -> returns active records in simplified `{id,name}` form.
  - `POST /api/masters/:table` -> creates a record (short form).
  - `PUT /api/masters/:table/:id` -> updates a record.
  - `DELETE /api/masters/:table/:id` -> deletes a record.

### 2.2 Entries (inventory + ledger)
The main transactional flows are:
- Purchase (adds inventory + increases stock)
- Purchase Return (removes/adjusts inventory and ledger)
- Sales (deducts inventory using FIFO)
- Sales Return
- Grind / Flour Out / Flour Out Return
- Papad In
- Packing
- Advance
- Open (accounting/opening?)
- Weight Conversion
- Stock Adjust
- Voucher (journal-style)
- Vehicle movement

Each of these has its own backend router and page set.

### 2.3 Reports (read-only)
Reports are served primarily through:
- `backend/routes/reports.js` mounted at:
  - `/api/reports/*`
  - and accounts-style routes are also accessible via `/api/accounts/*`.

## 3) Inventory & Lot core workflows

### 3.1 Lot generation
There are multiple lot mechanisms present in code:
- `backend/routes/lots.js` provides sequential lot generator:
  - `GET /api/lots/next` (and also other lot history endpoints)
- Purchases also generate lots if missing (in purchase routes), often based on `LOTxxxx` pattern.

### 3.2 Inventory write model
- `stock` table stores movement rows (positive for purchase, negative for sale/deduction in some routes).
- `stock_lots` table stores lot-level remaining quantities.

### 3.3 FIFO deduction (Sales)
- In `backend/routes/sales.js` the sales POST:
  - Loads available lots ordered by `created_at ASC`.
  - Checks total availability.
  - Deducts lot by lot updating `stock_lots.remaining_quantity`.
  - Writes negative entries into `stock` for traceability.

### 3.4 Traceability (Lot history)
- `backend/routes/lots.js` offers:
  - `GET /api/lots/lot-history/:lotNo`
    - returns purchase/grind/sales/flour-output trace for that lot.

## 4) Ledger/workflow core
- Purchases and Sales call ledger helper functions in:
  - `backend/utils/ledgerHelper` (used in purchase/sales fixed routes)
- Accounts reports in `backend/routes/reports.js` are computed from transaction tables and advances.

## 5) Document map
- Index of all module workflow docs: `WORKFLOWS_INDEX.md`
- End-to-end entry points for each module: `MODULE_WORKFLOWS/<Module>.md`
- Exact UI route workflow docs: `PAGES_WORKFLOWS/<frontend-route>.md`

